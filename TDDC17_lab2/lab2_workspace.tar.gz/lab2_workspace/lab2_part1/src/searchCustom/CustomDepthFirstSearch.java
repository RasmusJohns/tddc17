package searchCustom;

import java.util.Random;


public class CustomDepthFirstSearch extends CustomGraphSearch{
	public CustomDepthFirstSearch(int maxDepth){
		super(true); // Temporary random choice, you need to true or false!
		System.out.println("Change line above in \"CustomDepthFirstSearch.java\"!");}
};
